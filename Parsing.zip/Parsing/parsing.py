import requests
from bs4 import BeautifulSoup
import csv
import lxml

URL_A_ADRESS = 'https://www.mashina.kg/search/mercedes-benz/all/?currency=2&sort_by=upped_at+desc&time_created=all&year_from=2015&page=1'
headers = {'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'}
csv_file = 'cars.csv'

def get_html(URL_A_ADRESS, params=None):
    r = requests.get(URL_A_ADRESS, headers=headers, params=params)
    return r

def get_total_pages(html):
    soup = BeautifulSoup(html, 'lxml')
    page_pag = soup.find_all('li', class_='page-item')
    if page_pag:
        return int(page_pag[-3].get_text())
    else:
        return 1

def get_content(html):
    soup = BeautifulSoup(html, 'lxml')
    items = soup.find_all('div',class_="list-item")

    cars = []
    for item in items:
        cars.append({
            'title' : item.find('h2', class_='name').get_text(strip=True),
            'price_dollars' : item.find('p', class_='price').find('strong').get_text(strip=True),
            'photo' : item.find('div', class_="thumb-item-carousel").find('img').get('data-src'),
            'characteristic' : item.find('div', class_="item-info-wrapper").get_text(strip=True)
        })
    return cars
    write_to_csv(cars)

def write_to_csv(items, path):
    with open(path, 'w', newline='') as csv_file:
        writer = csv.writer(csv_file, delimiter='/')
        writer.writerow(['title', 'price_dollars', 'photo', 'characteristic'])
        for item in items:
            writer.writerow([item['title'], item['price_dollars'], item['photo'], item['characteristic']])

def main():
    html = get_html(URL_A_ADRESS)
    if html.status_code == 200:
        cars = []
        total_pages = get_total_pages(html.text)
        for page in range(1 , total_pages+1):
            print(f'Страницы парсятся, пожалуйста подождите...')
            html = get_html(URL_A_ADRESS, params={'page':page})
            cars.extend(get_content(html.text))
            write_to_csv(cars, csv_file)
        write_to_csv(cars, csv_file)
        # print(f'Получено {len(cars)} машин')
        # os.startfile(file)
            # cars.extend(get_content(html.text))
        print(cars)

main()